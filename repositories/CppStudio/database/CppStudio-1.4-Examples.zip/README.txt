C++ Studio 1.4 – offline C++ examples

This archive contains 44 original C++ example programs.
Each program is a separate .cpp file in the examples/ folder.
Open index.csv to search by category, title, and implementation variant.

The topic coverage is informed by these public example indexes:
- GeeksforGeeks: https://www.geeksforgeeks.org/cpp/cpp-programming-examples/
- Programiz: https://www.programiz.com/cpp-programming/examples

Program code in this archive was written for C++ Studio. The reference links are
provided for further reading; the archive is not a copy of the websites' code.

Linear Search has three separate implementations in this archive:
- linear-search-std-find.cpp: Using std::find()
- linear-search-iterative.cpp: Iterative Implementation
- linear-search-recursive.cpp: Recursive Implementation

Analyze identifies the implementation style before running the matching checks.
It does not convert one Linear Search variant into another.
