#include <iostream>
#include <vector>

int main() {
    int rows{}, cols{};
    if (!(std::cin >> rows >> cols) || rows < 0 || cols < 0 || rows > 100 || cols > 100) return 1;
    std::vector<std::vector<int>> matrix(rows, std::vector<int>(cols));
    for (auto& row : matrix) for (int& value : row) if (!(std::cin >> value)) return 1;
    for (int c = 0; c < cols; ++c) {
        for (int r = 0; r < rows; ++r) std::cout << matrix[r][c] << (r + 1 == rows ? '\n' : ' ');
        if (rows == 0) std::cout << '\n';
    }
    return 0;
}
