#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0) return 1;
    std::vector<int> values(n);
    for (int& value : values) if (!(std::cin >> value)) return 1;
    int key{};
    if (!(std::cin >> key)) return 1;

    const auto found = std::find(values.begin(), values.end(), key);
    if (found == values.end()) {
        std::cout << "Not found\n";
    } else {
        std::cout << "Found at index " << std::distance(values.begin(), found) << '\n';
    }
    return 0;
}
