#include <iomanip>
#include <iostream>
#include <string>

struct Student {
    std::string name;
    int id{};
    double score{};
};

int main() {
    Student student;
    std::getline(std::cin, student.name);
    if (!(std::cin >> student.id >> student.score)) return 1;
    std::cout << student.name << '\n' << student.id << '\n'
              << std::fixed << std::setprecision(2) << student.score << '\n';
    return 0;
}
