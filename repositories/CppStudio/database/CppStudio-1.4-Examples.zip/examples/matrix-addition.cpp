#include <iostream>
#include <vector>

int main() {
    int rows{}, cols{};
    if (!(std::cin >> rows >> cols) || rows < 0 || cols < 0 || rows > 100 || cols > 100) return 1;
    std::vector<std::vector<long long>> a(rows, std::vector<long long>(cols));
    std::vector<std::vector<long long>> b(rows, std::vector<long long>(cols));
    for (auto& row : a) for (auto& value : row) if (!(std::cin >> value)) return 1;
    for (auto& row : b) for (auto& value : row) if (!(std::cin >> value)) return 1;
    for (int r = 0; r < rows; ++r) {
        for (int c = 0; c < cols; ++c) std::cout << a[r][c] + b[r][c] << (c + 1 == cols ? '\n' : ' ');
        if (cols == 0) std::cout << '\n';
    }
    return 0;
}
