#include <iostream>

int main() {
    long long n{};
    if (!(std::cin >> n)) return 1;
    bool isPrime = n >= 2;
    for (long long divisor = 2; divisor <= n / divisor && isPrime; ++divisor) {
        if (n % divisor == 0) isPrime = false;
    }
    std::cout << (isPrime ? "Prime" : "Not prime") << '\n';
    return 0;
}
