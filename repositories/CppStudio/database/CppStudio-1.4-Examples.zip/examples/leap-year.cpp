#include <iostream>

int main() {
    int year{};
    if (!(std::cin >> year)) return 1;
    const bool leap = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    std::cout << (leap ? "Leap year" : "Not a leap year") << '\n';
    return 0;
}
