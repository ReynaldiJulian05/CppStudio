#include <iostream>

int main() {
    double base{};
    int exponent{};
    if (!(std::cin >> base >> exponent) || exponent < 0) return 1;
    double result = 1.0;
    for (int i = 0; i < exponent; ++i) result *= base;
    std::cout << result << '\n';
    return 0;
}
