#include <cstdlib>
#include <iostream>
#include <numeric>

int main() {
    long long a{}, b{};
    if (!(std::cin >> a >> b)) return 1;
    if (a == 0 || b == 0) {
        std::cout << 0 << '\n';
    } else {
        const long long divisor = std::gcd(a, b);
        std::cout << std::llabs((a / divisor) * b) << '\n';
    }
    return 0;
}
