#include <iostream>
#include <string>

int main() {
    std::string text;
    std::getline(std::cin, text);
    std::cout << text.size() << '\n';
    return 0;
}
