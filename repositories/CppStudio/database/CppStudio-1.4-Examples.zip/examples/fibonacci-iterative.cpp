#include <iostream>

int main() {
    int count{};
    if (!(std::cin >> count) || count < 0 || count > 90) return 1;
    unsigned long long a = 0, b = 1;
    for (int i = 0; i < count; ++i) {
        std::cout << a << (i + 1 == count ? '\n' : ' ');
        const unsigned long long next = a + b;
        a = b;
        b = next;
    }
    if (count == 0) std::cout << '\n';
    return 0;
}
