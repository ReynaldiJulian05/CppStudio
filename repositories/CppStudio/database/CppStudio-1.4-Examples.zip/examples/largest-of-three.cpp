#include <algorithm>
#include <iostream>

int main() {
    int a{}, b{}, c{};
    if (!(std::cin >> a >> b >> c)) return 1;
    std::cout << std::max({a, b, c}) << '\n';
    return 0;
}
