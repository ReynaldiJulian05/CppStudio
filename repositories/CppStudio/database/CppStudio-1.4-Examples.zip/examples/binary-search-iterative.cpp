#include <iostream>
#include <vector>

int binarySearch(const std::vector<int>& values, int key) {
    int low = 0;
    int high = static_cast<int>(values.size()) - 1;
    while (low <= high) {
        const int mid = low + (high - low) / 2;
        if (values[mid] == key) return mid;
        if (values[mid] < key) low = mid + 1;
        else high = mid - 1;
    }
    return -1;
}

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0) return 1;
    std::vector<int> values(n);
    for (int& value : values) if (!(std::cin >> value)) return 1;
    int key{};
    if (!(std::cin >> key)) return 1;
    std::cout << binarySearch(values, key) << '\n';
    return 0;
}
