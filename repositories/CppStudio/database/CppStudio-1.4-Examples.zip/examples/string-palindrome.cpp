#include <iostream>
#include <string>

int main() {
    std::string text;
    std::getline(std::cin, text);
    bool palindrome = true;
    for (std::size_t i = 0; i < text.size() / 2; ++i) {
        if (text[i] != text[text.size() - 1 - i]) {
            palindrome = false;
            break;
        }
    }
    std::cout << (palindrome ? "Palindrome" : "Not palindrome") << '\n';
    return 0;
}
