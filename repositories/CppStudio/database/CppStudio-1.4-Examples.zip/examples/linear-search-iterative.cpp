#include <iostream>
#include <vector>

int linearSearch(const std::vector<int>& values, int key) {
    for (int i = 0; i < static_cast<int>(values.size()); ++i) {
        if (values[i] == key) return i;
    }
    return -1;
}

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0) return 1;
    std::vector<int> values(n);
    for (int& value : values) if (!(std::cin >> value)) return 1;
    int key{};
    if (!(std::cin >> key)) return 1;
    std::cout << linearSearch(values, key) << '\n';
    return 0;
}
