#include <iostream>

long long fibonacci(int n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0 || n > 40) return 1;
    std::cout << fibonacci(n) << '\n';
    return 0;
}
