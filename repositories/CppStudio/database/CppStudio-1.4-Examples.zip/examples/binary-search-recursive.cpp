#include <iostream>
#include <vector>

int binarySearchRecursive(const std::vector<int>& values, int key, int low, int high) {
    if (low > high) return -1;
    const int mid = low + (high - low) / 2;
    if (values[mid] == key) return mid;
    if (values[mid] < key) return binarySearchRecursive(values, key, mid + 1, high);
    return binarySearchRecursive(values, key, low, mid - 1);
}

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0) return 1;
    std::vector<int> values(n);
    for (int& value : values) if (!(std::cin >> value)) return 1;
    int key{};
    if (!(std::cin >> key)) return 1;
    std::cout << binarySearchRecursive(values, key, 0, n - 1) << '\n';
    return 0;
}
