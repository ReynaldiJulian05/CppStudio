#include <iostream>

int main() {
    long long number{};
    if (!(std::cin >> number)) return 1;
    std::cout << (number % 2 == 0 ? "Even" : "Odd") << '\n';
    return 0;
}
