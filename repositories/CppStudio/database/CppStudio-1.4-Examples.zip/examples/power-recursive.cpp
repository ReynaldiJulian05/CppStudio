#include <iostream>

double power(double base, unsigned int exponent) {
    if (exponent == 0) return 1.0;
    return base * power(base, exponent - 1);
}

int main() {
    double base{};
    unsigned int exponent{};
    if (!(std::cin >> base >> exponent) || exponent > 10000) return 1;
    std::cout << power(base, exponent) << '\n';
    return 0;
}
