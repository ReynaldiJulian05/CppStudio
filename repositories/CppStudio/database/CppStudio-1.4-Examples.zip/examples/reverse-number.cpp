#include <iostream>
#include <limits>

int main() {
    long long number{};
    if (!(std::cin >> number)) return 1;
    long long remaining = number;
    long long reversed = 0;
    while (remaining != 0) {
        const int digit = static_cast<int>(remaining % 10);
        if (reversed > (std::numeric_limits<long long>::max() - digit) / 10 ||
            reversed < (std::numeric_limits<long long>::min() - digit) / 10) return 1;
        reversed = reversed * 10 + digit;
        remaining /= 10;
    }
    std::cout << reversed << '\n';
    return 0;
}
