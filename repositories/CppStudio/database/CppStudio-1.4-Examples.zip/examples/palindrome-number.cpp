#include <iostream>

int main() {
    long long number{};
    if (!(std::cin >> number) || number < 0) return 1;
    long long remaining = number, reversed = 0;
    while (remaining > 0) {
        reversed = reversed * 10 + remaining % 10;
        remaining /= 10;
    }
    std::cout << (number == reversed ? "Palindrome" : "Not palindrome") << '\n';
    return 0;
}
