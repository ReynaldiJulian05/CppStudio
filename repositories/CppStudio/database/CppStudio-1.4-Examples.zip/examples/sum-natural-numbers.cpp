#include <iostream>

int main() {
    long long n{};
    if (!(std::cin >> n) || n < 0) return 1;
    long long total = 0;
    for (long long i = 1; i <= n; ++i) total += i;
    std::cout << total << '\n';
    return 0;
}
