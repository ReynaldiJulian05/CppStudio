#include <algorithm>
#include <iostream>
#include <string>

int main() {
    std::string text;
    std::getline(std::cin, text);
    std::reverse(text.begin(), text.end());
    std::cout << text << '\n';
    return 0;
}
