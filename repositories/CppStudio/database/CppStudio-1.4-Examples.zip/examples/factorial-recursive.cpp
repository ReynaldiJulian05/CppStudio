#include <iostream>

unsigned long long factorial(int n) {
    if (n <= 1) return 1;
    return static_cast<unsigned long long>(n) * factorial(n - 1);
}

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0 || n > 20) return 1;
    std::cout << factorial(n) << '\n';
    return 0;
}
