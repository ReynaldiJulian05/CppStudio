#include <iomanip>
#include <iostream>
#include <vector>

int main() {
    int n{};
    if (!(std::cin >> n) || n <= 0 || n > 100000) return 1;
    long double total = 0.0L;
    for (int i = 0; i < n; ++i) {
        long double value{};
        if (!(std::cin >> value)) return 1;
        total += value;
    }
    std::cout << std::fixed << std::setprecision(2) << total / n << '\n';
    return 0;
}
