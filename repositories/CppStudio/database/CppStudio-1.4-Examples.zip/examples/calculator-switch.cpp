#include <iostream>

int main() {
    double a{}, b{};
    char operation{};
    if (!(std::cin >> a >> operation >> b)) return 1;
    switch (operation) {
        case '+': std::cout << a + b; break;
        case '-': std::cout << a - b; break;
        case '*': std::cout << a * b; break;
        case '/':
            if (b == 0.0) { std::cout << "Division by zero is not allowed"; return 1; }
            std::cout << a / b;
            break;
        default: std::cout << "Unknown operator"; return 1;
    }
    std::cout << '\n';
    return 0;
}
