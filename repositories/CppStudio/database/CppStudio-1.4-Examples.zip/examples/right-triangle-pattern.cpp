#include <iostream>

int main() {
    int height{};
    if (!(std::cin >> height) || height < 0 || height > 100) return 1;
    for (int row = 1; row <= height; ++row) {
        for (int col = 0; col < row; ++col) std::cout << '*';
        std::cout << '\n';
    }
    return 0;
}
