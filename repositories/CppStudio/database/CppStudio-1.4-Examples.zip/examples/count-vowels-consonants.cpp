#include <cctype>
#include <iostream>
#include <string>

int main() {
    std::string text;
    std::getline(std::cin, text);
    int vowels = 0, consonants = 0;
    for (unsigned char ch : text) {
        if (!std::isalpha(ch)) continue;
        const char lower = static_cast<char>(std::tolower(ch));
        if (lower == 'a' || lower == 'e' || lower == 'i' || lower == 'o' || lower == 'u') ++vowels;
        else ++consonants;
    }
    std::cout << vowels << ' ' << consonants << '\n';
    return 0;
}
