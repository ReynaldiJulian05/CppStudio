#include <utility>
#include <iostream>
#include <vector>

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0) return 1;
    std::vector<int> values(n);
    for (int& value : values) if (!(std::cin >> value)) return 1;
    for (int end = n - 1; end > 0; --end) {
        bool swapped = false;
        for (int j = 0; j < end; ++j) {
            if (values[j] > values[j + 1]) {
                std::swap(values[j], values[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
    }
    for (int i = 0; i < n; ++i) std::cout << values[i] << (i + 1 == n ? '\n' : ' ');
    if (n == 0) std::cout << '\n';
    return 0;
}
