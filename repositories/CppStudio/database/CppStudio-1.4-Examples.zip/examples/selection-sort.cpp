#include <utility>
#include <iostream>
#include <vector>

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0) return 1;
    std::vector<int> values(n);
    for (int& value : values) if (!(std::cin >> value)) return 1;
    for (int i = 0; i < n; ++i) {
        int minimumIndex = i;
        for (int j = i + 1; j < n; ++j) {
            if (values[j] < values[minimumIndex]) minimumIndex = j;
        }
        std::swap(values[i], values[minimumIndex]);
    }
    for (int i = 0; i < n; ++i) std::cout << values[i] << (i + 1 == n ? '\n' : ' ');
    if (n == 0) std::cout << '\n';
    return 0;
}
