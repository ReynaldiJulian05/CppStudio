#include <iostream>

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0 || n > 20) return 1;
    unsigned long long result = 1;
    for (int i = 2; i <= n; ++i) result *= static_cast<unsigned long long>(i);
    std::cout << result << '\n';
    return 0;
}
