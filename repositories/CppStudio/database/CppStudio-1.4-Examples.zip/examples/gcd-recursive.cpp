#include <cstdlib>
#include <iostream>

long long gcd(long long a, long long b) {
    if (b == 0) return std::llabs(a);
    return gcd(b, a % b);
}

int main() {
    long long a{}, b{};
    if (!(std::cin >> a >> b)) return 1;
    std::cout << gcd(a, b) << '\n';
    return 0;
}
