#include <cstdlib>
#include <iostream>

int main() {
    long long a{}, b{};
    if (!(std::cin >> a >> b)) return 1;
    a = std::llabs(a);
    b = std::llabs(b);
    while (b != 0) {
        const long long remainder = a % b;
        a = b;
        b = remainder;
    }
    std::cout << a << '\n';
    return 0;
}
