#include <iostream>
#include <limits>
#include <vector>

int main() {
    int n{};
    if (!(std::cin >> n) || n <= 0 || n > 100000) return 1;
    long long minimum = std::numeric_limits<long long>::max();
    long long maximum = std::numeric_limits<long long>::lowest();
    for (int i = 0; i < n; ++i) {
        long long value{};
        if (!(std::cin >> value)) return 1;
        if (value < minimum) minimum = value;
        if (value > maximum) maximum = value;
    }
    std::cout << minimum << ' ' << maximum << '\n';
    return 0;
}
