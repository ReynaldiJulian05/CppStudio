#include <iostream>
#include <vector>

int linearSearchRecursive(const std::vector<int>& values, int key, std::size_t index = 0) {
    if (index >= values.size()) return -1;
    if (values[index] == key) return static_cast<int>(index);
    return linearSearchRecursive(values, key, index + 1);
}

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0) return 1;
    std::vector<int> values(n);
    for (int& value : values) if (!(std::cin >> value)) return 1;
    int key{};
    if (!(std::cin >> key)) return 1;
    std::cout << linearSearchRecursive(values, key) << '\n';
    return 0;
}
