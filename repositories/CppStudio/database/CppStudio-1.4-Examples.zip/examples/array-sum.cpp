#include <iostream>
#include <vector>

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0 || n > 100000) return 1;
    std::vector<long long> values(n);
    long long total = 0;
    for (auto& value : values) {
        if (!(std::cin >> value)) return 1;
        total += value;
    }
    std::cout << total << '\n';
    return 0;
}
