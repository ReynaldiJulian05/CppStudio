#include <iostream>

int main() {
    int value{};
    std::cout << "Enter an integer: ";
    if (!(std::cin >> value)) {
        std::cerr << "Invalid integer input\n";
        return 1;
    }
    std::cout << "You entered: " << value << '\n';
    return 0;
}
