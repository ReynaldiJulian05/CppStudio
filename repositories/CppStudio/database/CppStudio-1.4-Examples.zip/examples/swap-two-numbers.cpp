#include <iostream>

int main() {
    int a{}, b{};
    if (!(std::cin >> a >> b)) return 1;
    int temporary = a;
    a = b;
    b = temporary;
    std::cout << a << ' ' << b << '\n';
    return 0;
}
