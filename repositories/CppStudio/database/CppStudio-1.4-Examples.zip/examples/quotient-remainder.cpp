#include <iostream>

int main() {
    long long a{}, b{};
    if (!(std::cin >> a >> b)) return 1;
    if (b == 0) {
        std::cout << "Division by zero is not allowed\n";
        return 1;
    }
    std::cout << "Quotient: " << a / b << '\n';
    std::cout << "Remainder: " << a % b << '\n';
    return 0;
}
