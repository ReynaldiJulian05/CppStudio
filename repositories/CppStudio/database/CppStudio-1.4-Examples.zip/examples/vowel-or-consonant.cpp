#include <cctype>
#include <iostream>

int main() {
    char ch{};
    if (!(std::cin >> ch)) return 1;
    const char lower = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    if (!std::isalpha(static_cast<unsigned char>(ch))) {
        std::cout << "Not an alphabet\n";
    } else if (lower == 'a' || lower == 'e' || lower == 'i' || lower == 'o' || lower == 'u') {
        std::cout << "Vowel\n";
    } else {
        std::cout << "Consonant\n";
    }
    return 0;
}
