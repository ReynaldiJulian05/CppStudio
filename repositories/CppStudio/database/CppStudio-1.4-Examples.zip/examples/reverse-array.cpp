#include <utility>
#include <iostream>
#include <vector>

int main() {
    int n{};
    if (!(std::cin >> n) || n < 0) return 1;
    std::vector<int> values(n);
    for (int& value : values) if (!(std::cin >> value)) return 1;
    int left = 0;
    int right = n - 1;
    while (left < right) {
        std::swap(values[left], values[right]);
        ++left;
        --right;
    }
    for (int i = 0; i < n; ++i) std::cout << values[i] << (i + 1 == n ? '\n' : ' ');
    if (n == 0) std::cout << '\n';
    return 0;
}
