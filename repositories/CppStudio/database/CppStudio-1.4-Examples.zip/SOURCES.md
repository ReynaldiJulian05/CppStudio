# Reference indexes

- [GeeksforGeeks – C++ Programming Examples](https://www.geeksforgeeks.org/cpp/cpp-programming-examples/)
- [Programiz – C++ Examples](https://www.programiz.com/cpp-programming/examples)
- [GeeksforGeeks – Linear Search](https://www.geeksforgeeks.org/dsa/linear-search/)
- [Programiz – Linear Search](https://www.programiz.com/dsa/linear-search)

These pages inform topic coverage and further reading. Example code in this
database is authored for C++ Studio and is not copied from the reference pages.
